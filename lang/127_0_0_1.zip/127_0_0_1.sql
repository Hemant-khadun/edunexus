-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2024 at 07:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edu_nexus`
--
CREATE DATABASE IF NOT EXISTS `edu_nexus` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `edu_nexus`;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('cb4e5208b4cd87268b208e49452ed6e89a68e0b8', 'i:1;', 1719941953),
('cb4e5208b4cd87268b208e49452ed6e89a68e0b8:timer', 'i:1719941953;', 1719941953),
('f71a3f8b7ba3de91e091d0867bd86154', 'i:1;', 1719089710),
('f71a3f8b7ba3de91e091d0867bd86154:timer', 'i:1719089710;', 1719089710),
('fortify.2fa_codes.10a4656d6821d6875d4ed2d643a21f43', 'i:57331403;', 1719942155),
('hemwunt@edunexus.com|127.0.0.1', 'i:1;', 1719089711),
('hemwunt@edunexus.com|127.0.0.1:timer', 'i:1719089711;', 1719089711);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(2, 'Video', 'This Category will help students to filter and view all the videos in the course', '2024-07-08 13:41:03', '2024-07-08 13:41:03'),
(3, 'File', 'This filter will help student get all the files in the course', '2024-07-08 13:41:24', '2024-07-08 13:41:24'),
(4, 'Text', 'This will help students to filter by text', '2024-07-08 15:20:10', '2024-07-08 15:20:10');

-- --------------------------------------------------------

--
-- Table structure for table `completed_courses`
--

CREATE TABLE `completed_courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `completed_courses`
--

INSERT INTO `completed_courses` (`id`, `user_id`, `course_id`, `created_at`, `updated_at`) VALUES
(1, 31, 20, '2024-06-30 13:42:49', '2024-06-30 13:42:49'),
(3, 31, 21, '2024-06-30 15:52:55', '2024-06-30 15:52:55'),
(7, 31, 22, '2024-07-01 14:31:25', '2024-07-01 14:31:25'),
(8, 33, 20, '2024-07-02 15:06:41', '2024-07-02 15:06:41'),
(9, 33, 21, '2024-07-02 15:06:47', '2024-07-02 15:06:47'),
(10, 33, 22, '2024-07-02 15:07:26', '2024-07-02 15:07:26'),
(11, 33, 26, '2024-07-02 15:55:32', '2024-07-02 15:55:32'),
(12, 31, 29, '2024-07-04 18:32:50', '2024-07-04 18:32:50'),
(13, 31, 34, '2024-07-08 16:05:47', '2024-07-08 16:05:47');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `material_id` bigint(20) UNSIGNED NOT NULL,
  `program_id` bigint(20) UNSIGNED NOT NULL,
  `topic_id` bigint(20) UNSIGNED DEFAULT NULL,
  `wrapper_id` bigint(20) UNSIGNED DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `author_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_name`, `description`, `subject_id`, `material_id`, `program_id`, `topic_id`, `wrapper_id`, `category_id`, `author_id`, `created_at`, `updated_at`) VALUES
(15, 'test course', 'test', 2, 2, 25, 11, 1, 0, 8, '2024-06-27 16:28:56', '2024-06-30 03:58:00'),
(16, 'test 2', 'test  2', 1, 1, 24, 6, 1, 0, 8, '2024-06-29 07:02:54', '2024-06-30 03:57:43'),
(17, 'test file 2', 'test  test2', 2, 5, 25, 10, 2, 0, 8, '2024-06-29 07:55:01', '2024-06-30 03:57:20'),
(18, 'test override files', 'test  t2  wda', 2, 5, 20, 3, 1, 0, 8, '2024-06-29 08:04:54', '2024-07-04 15:47:10'),
(19, 'Test text', 'test', 2, 6, 24, 6, 2, 0, 8, '2024-06-29 08:17:59', '2024-06-30 03:56:53'),
(20, 'Additions and substraction', 'This course will teach you how to do calculations', 1, 6, 20, 14, 3, 4, 13, '2024-06-29 14:29:30', '2024-07-08 15:23:07'),
(21, 'Learning with word document', 'Test', 1, 5, 20, 3, NULL, 0, 13, '2024-06-30 14:01:13', '2024-06-30 14:01:13'),
(22, 'Final Test', 'Complete this quiz to earn your certificate', 1, 2, 20, 3, NULL, 0, 13, '2024-07-01 12:11:32', '2024-07-01 12:11:32'),
(25, 'Test PDF', 'TEST PDF', 1, 5, 20, 3, 2, 0, 8, '2024-07-02 14:06:51', '2024-07-02 14:06:51'),
(26, 'Quiz test', 'This is a quiz for mathematics', 2, 2, 20, 13, NULL, 0, 13, '2024-07-02 15:32:30', '2024-07-02 15:32:30'),
(27, 'Abaccus', 'Lets learn about abacus together', 1, 6, 20, 3, NULL, 0, 13, '2024-07-04 15:58:15', '2024-07-04 15:58:15'),
(29, 'Fractions', 'Test', 1, 6, 20, 14, 3, 3, 13, '2024-07-04 16:08:18', '2024-07-08 15:23:48'),
(30, 'test course', 'You will learn how to read clock in this course', 2, 6, 25, 16, 4, 0, 13, '2024-07-07 10:01:59', '2024-07-07 11:29:37'),
(31, 'test', 'test', 2, 6, 25, 16, 4, 0, 13, '2024-07-07 11:41:47', '2024-07-07 11:41:47'),
(32, 'test awdawd', 'awdawdawd', 2, 6, 25, 17, 4, 0, 13, '2024-07-07 11:43:02', '2024-07-07 11:43:02'),
(33, 'wadawd', 'awdawd', 2, 6, 25, 16, 4, 0, 13, '2024-07-07 11:43:16', '2024-07-07 11:43:16'),
(39, 'Test corauwdhwad', 'dawd', 1, 6, 20, 21, 3, 4, 13, '2024-07-09 15:18:07', '2024-07-09 15:18:07');

-- --------------------------------------------------------

--
-- Table structure for table `course_wrappers`
--

CREATE TABLE `course_wrappers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `author_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course_wrappers`
--

INSERT INTO `course_wrappers` (`id`, `title`, `description`, `author_id`, `created_at`, `updated_at`) VALUES
(2, 'test 2', 'test deacawd 2 a daw da test deacawd 2 a daw da test deacawd 2 a daw da test deacawd 2 a daw da test deacawd 2 a daw da dawd', 8, '2024-07-04 15:47:25', '2024-07-04 15:51:16'),
(3, 'Maths Course', 'This course will teach you a lot', 13, '2024-07-04 15:56:29', '2024-07-07 10:03:25'),
(4, 'English Course', 'This is a small description', 13, '2024-07-07 10:00:17', '2024-07-07 10:03:14'),
(5, 'Programing', 'This will teach you programting', 13, '2024-07-09 12:51:27', '2024-07-09 12:51:27');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `follower_id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `followers`
--

INSERT INTO `followers` (`id`, `course_id`, `follower_id`, `status`, `created_at`, `updated_at`) VALUES
(22, 3, 31, 1, '2024-07-08 18:33:56', '2024-07-08 18:34:18');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `materials`
--

CREATE TABLE `materials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `materials`
--

INSERT INTO `materials` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Video', 'This material type helps to upload video for explanations', '2024-06-22 12:36:10', '2024-06-22 12:36:10'),
(2, 'Quiz', 'This helps to create custom quiz to assess the student', '2024-06-22 12:52:04', '2024-06-22 12:52:04'),
(5, 'File', 'Allows students to upload and access document files, such as PDFs, Word documents, or presentations. This type of material is useful for sharing course-related resources, lecture notes, or additional reading materials.', '2024-06-23 08:31:53', '2024-06-23 08:31:53'),
(6, 'Text', 'Provides a space for instructors to share textual content with students. This can include lecture notes, reading assignments, or any other written information relevant to the course.', '2024-06-23 08:33:59', '2024-06-23 08:33:59');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `disk` varchar(255) NOT NULL,
  `conversions_disk` varchar(255) DEFAULT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
(18, 'App\\Models\\Program', 20, '1c5fa0a3-d529-4f67-a044-133da69990b3', 'program_thumbnails', 'g1', 'g1.png', 'image/png', 'public', 'public', 226784, '[]', '[]', '[]', '[]', 1, '2024-06-21 13:54:29', '2024-06-21 13:54:29'),
(29, 'App\\Models\\Program', 24, '60e28867-2226-40af-8205-f7d1e25bad40', 'program_thumbnails', 'g2', 'g2.png', 'image/png', 'public', 'public', 528592, '[]', '[]', '[]', '[]', 1, '2024-06-21 14:14:37', '2024-06-21 14:14:37'),
(30, 'App\\Models\\Program', 25, '71f63435-d606-4dc6-acb4-a85befb1cad6', 'program_thumbnails', 'g3', 'g3.png', 'image/png', 'public', 'public', 448177, '[]', '[]', '[]', '[]', 1, '2024-06-21 14:14:48', '2024-06-21 14:14:48'),
(31, 'App\\Models\\Program', 26, 'e49907e5-1a3b-408e-938b-b50cd88eb0a5', 'program_thumbnails', 'g4', 'g4.png', 'image/png', 'public', 'public', 198850, '[]', '[]', '[]', '[]', 1, '2024-06-21 14:15:03', '2024-06-21 14:15:03'),
(32, 'App\\Models\\Program', 27, '7935503a-1c87-4dd8-b7f5-16c75d73558f', 'program_thumbnails', 'g5', 'g5.png', 'image/png', 'public', 'public', 117897, '[]', '[]', '[]', '[]', 1, '2024-06-21 14:15:18', '2024-06-21 14:15:18'),
(33, 'App\\Models\\Courses', 16, '913cb0f9-09f9-45aa-b6e3-15915baf8585', 'videos', 'file_example_MP4_1280_10MG', 'file_example_MP4_1280_10MG.mp4', 'video/mp4', 'public', 'public', 9840497, '[]', '[]', '[]', '[]', 1, '2024-06-29 07:02:54', '2024-06-29 07:02:54'),
(37, 'App\\Models\\Courses', 17, '73f32085-bd2b-48d8-8374-cddb9422d746', 'files', 'formula-numbers-logo', 'formula-numbers-logo.webp', 'image/webp', 'public', 'public', 43940, '[]', '[]', '[]', '[]', 1, '2024-06-29 08:02:47', '2024-06-29 08:02:47'),
(39, 'App\\Models\\Courses', 18, '26ca5218-971a-415a-aced-62a8fdc79743', 'files', 'WhatsApp Image 2024-06-26 at 22.42.50', 'WhatsApp-Image-2024-06-26-at-22.42.50.jpeg', 'image/jpeg', 'public', 'public', 348069, '[]', '[]', '[]', '[]', 1, '2024-06-29 08:05:07', '2024-06-29 08:05:07'),
(43, 'App\\Models\\Courses', 25, 'c2081a6c-7902-436f-ae03-bd9f9a571554', 'files', 'functionalities - Sheet4 (1)-1', 'functionalities---Sheet4-(1)-1.pdf', 'application/pdf', 'public', 'public', 59272, '[]', '[]', '[]', '[]', 1, '2024-07-02 14:06:51', '2024-07-02 14:06:51'),
(44, 'App\\Models\\Courses', 21, 'eb31df4e-39ef-4bf5-bf80-3b73a7e13f1a', 'files', 'functionalities - Sheet4 (1)-1', 'functionalities---Sheet4-(1)-1.pdf', 'application/pdf', 'public', 'public', 59272, '[]', '[]', '[]', '[]', 1, '2024-07-02 14:08:06', '2024-07-02 14:08:06');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_06_16_062541_add_two_factor_columns_to_users_table', 1),
(5, '2024_06_16_062621_create_personal_access_tokens_table', 1),
(6, '2024_06_16_062621_create_teams_table', 1),
(7, '2024_06_16_062622_create_team_user_table', 1),
(8, '2024_06_16_062623_create_team_invitations_table', 1),
(9, '2024_06_19_174554_create_programs_table', 2),
(10, '2024_06_19_192648_add_file_name_and_title_to_programs_table', 3),
(11, '2024_06_19_192648_add_file_name_and_title_programs_table', 4),
(12, '2024_06_21_121852_create_media_table', 5),
(13, '2024_06_22_020512_create_subjects_table', 6),
(14, '2024_06_22_042021_create_materials_table', 7),
(15, '2024_06_23_090412_add_role_and_status_to_users_table', 8),
(16, '2024_06_23_095148_add_active_status_to_users_table', 9),
(17, '2024_06_23_114025_add_courses_table', 10),
(18, '2024_06_25_172557_create_quizzes_table', 11),
(19, '2024_06_25_173318_create_text_contents_table', 11),
(20, '2024_06_25_174413_create_quiz_answers_table', 11),
(21, '2024_06_25_175240_remove_duration_column_from_courses', 12),
(22, '2024_06_26_202524_add_author_to_courses', 13),
(23, '2024_06_27_163145_update_quiz_asnwers_table', 14),
(24, '2024_06_29_171037_create_followers_table', 15),
(25, '2024_06_30_040019_add_grade_to_users', 16),
(26, '2024_06_30_050530_create_topics_table', 17),
(27, '2024_06_30_061556_add_topic_id_to_courses_table', 18),
(28, '2024_06_30_121636_add_status_to_followers_table', 19),
(29, '2024_06_30_172058_create_completed_courses_table', 20),
(30, '2024_07_01_161634_create_student_answers_table', 21),
(31, '2024_07_01_173216_add_is_good_to_quiz_answers', 22),
(32, '2024_07_04_172019_create_course_wrappers_table', 23),
(33, '2024_07_04_190447_add_wrappers_id_to_courses', 24),
(34, '2024_07_04_201122_add_author_id_to_topics', 25),
(35, '2024_07_08_163937_create_categories_courses', 26);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `title`, `thumbnail`, `created_at`, `updated_at`) VALUES
(20, 'Grade 1', 'g1.png', '2024-06-21 13:54:29', '2024-07-02 13:55:13'),
(24, 'Grade 2', 'g2.png', '2024-06-21 14:13:06', '2024-06-21 14:14:37'),
(25, 'Grade 3', 'g3.png', '2024-06-21 14:14:48', '2024-06-21 14:14:48'),
(26, 'Grade 4', 'g4.png', '2024-06-21 14:15:03', '2024-06-21 14:15:03'),
(27, 'Grade 5', 'g5.png', '2024-06-21 14:15:18', '2024-06-21 14:15:18');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `course_id`, `question`, `created_at`, `updated_at`) VALUES
(19, 15, 'Q1', '2024-06-27 16:40:28', '2024-06-27 16:40:28'),
(20, 15, 'Q10', '2024-06-27 16:42:55', '2024-06-27 16:42:55'),
(21, 15, 'Q101', '2024-06-27 17:03:48', '2024-06-27 17:03:48'),
(22, 15, 'Q1012312', '2024-06-27 17:04:00', '2024-06-27 17:04:00'),
(23, 22, 'How much is 1+2?', '2024-07-01 12:11:32', '2024-07-01 12:11:32'),
(24, 22, 'How much is 9-4 ?', '2024-07-01 12:11:32', '2024-07-01 12:11:32'),
(25, 22, 'How much is 10+4', '2024-07-01 12:11:32', '2024-07-01 12:11:32'),
(28, 22, 'How much is 1+2 ?', '2024-07-02 13:48:24', '2024-07-02 13:48:24'),
(29, 26, 'What is a verb ?', '2024-07-02 15:32:30', '2024-07-02 15:32:30');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_answers`
--

CREATE TABLE `quiz_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quiz_id` bigint(20) UNSIGNED NOT NULL,
  `answer` text NOT NULL,
  `is_good` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quiz_answers`
--

INSERT INTO `quiz_answers` (`id`, `quiz_id`, `answer`, `is_good`, `created_at`, `updated_at`) VALUES
(52, 20, 'A3', 0, '2024-06-27 16:42:55', '2024-06-27 16:42:55'),
(53, 21, 'A1', 0, '2024-06-27 17:03:48', '2024-06-27 17:03:48'),
(58, 22, 'A3', 0, '2024-06-27 17:04:01', '2024-06-27 17:04:01'),
(59, 19, 'test3', 0, '2024-06-27 17:04:34', '2024-06-27 17:04:34'),
(117, 25, '14', 1, '2024-07-02 12:45:53', '2024-07-02 12:45:53'),
(122, 24, '5', 1, '2024-07-02 12:46:58', '2024-07-02 12:46:58'),
(128, 23, '3', 1, '2024-07-02 13:12:08', '2024-07-02 13:12:08'),
(142, 23, '5', 0, '2024-07-02 13:14:44', '2024-07-02 13:14:44'),
(143, 23, '4', 0, '2024-07-02 13:14:44', '2024-07-02 13:14:44'),
(144, 23, '2', 0, '2024-07-02 13:14:44', '2024-07-02 13:14:44'),
(145, 24, '8', 0, '2024-07-02 13:14:45', '2024-07-02 13:14:45'),
(146, 24, '6', 0, '2024-07-02 13:14:45', '2024-07-02 13:14:45'),
(147, 24, '4', 0, '2024-07-02 13:14:45', '2024-07-02 13:14:45'),
(148, 25, '11', 0, '2024-07-02 13:14:45', '2024-07-02 13:14:45'),
(149, 25, '18', 0, '2024-07-02 13:14:45', '2024-07-02 13:14:45'),
(150, 25, '15', 0, '2024-07-02 13:14:45', '2024-07-02 13:14:45'),
(151, 28, '3', 1, '2024-07-02 13:48:24', '2024-07-02 13:48:24'),
(152, 28, '5', 0, '2024-07-02 13:48:24', '2024-07-02 13:48:24'),
(153, 28, '4', 0, '2024-07-02 13:48:24', '2024-07-02 13:48:24'),
(154, 28, '2', 0, '2024-07-02 13:48:24', '2024-07-02 13:48:24'),
(156, 29, 'this is not a verb', 0, '2024-07-02 15:32:30', '2024-07-02 15:32:30'),
(157, 29, 'this is a verb', 1, '2024-07-02 15:32:50', '2024-07-02 15:32:50'),
(158, 19, 'A3', 1, '2024-07-05 16:28:37', '2024-07-05 16:28:37'),
(159, 20, 'A2', 1, '2024-07-05 16:28:37', '2024-07-05 16:28:37'),
(160, 21, 'A3', 1, '2024-07-05 16:28:37', '2024-07-05 16:28:37'),
(161, 22, 'A2', 1, '2024-07-05 16:28:37', '2024-07-05 16:28:37');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('C2y7WPVUKCt7Oy3mD1wLaMhRNf202atxYCMN8TtU', 8, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoidW1kOU05T2Z2c04ycHFTblUzRTRndTl3aDRmMjJqRUdUUEVjQndkayI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9lZHVuZXh1cy50ZXN0L3VzZXJzIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6ODtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMiRsL2M0QXgwTjYvbUloTTA0QkRpLjd1WW1LdEdMbTU3YXl1bjMucGFZaTE3MlNpZi4vckR1RyI7fQ==', 1720583807),
('h4l0pmgt34rMAf4sb6CugzqwkhHGiSZDGAi2I6CE', 13, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiR3lIalV5M0kweEhUVG1sT0lpNThsaVVDdEdhZExmdk5IUVh1NVAzNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHA6Ly9lZHVuZXh1cy50ZXN0L2xlYXJuaW5nL2NvbnRlbnQvNSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjEzO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJ5JDEyJGxmNUVnSlFJeEtFRW5zVTU1YmZyVE94S0lzRUtxanhxc2lRRlo2WmJvZVRJQllBcS9pZzUuIjt9', 1720552728),
('R3OxsEHK0VinaIrXCfffrgqrs4iRK1x98GfsvBoA', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZVlIYkM3c2I0SkE0NEFwOWczME9GeG0wRzlDUHRSQ2x4U1JpVmZ3SiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTY6Imh0dHA6Ly9sb2NhbGhvc3QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1720545545),
('XRuxtzindNS1RY1AD9SqD6r7xqng36BQIxHzPTJq', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibHZSUW8yS3RCUHJheHNQbGxUOU1uOXF2VU1DcmNxWW1UeVEwOFFKZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHA6Ly9lZHVuZXh1cy50ZXN0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1721842325);

-- --------------------------------------------------------

--
-- Table structure for table `student_answers`
--

CREATE TABLE `student_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `answer_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_answers`
--

INSERT INTO `student_answers` (`id`, `answer_id`, `user_id`, `created_at`, `updated_at`) VALUES
(6, 128, 33, '2024-07-02 15:07:04', '2024-07-02 15:07:04'),
(7, 122, 33, '2024-07-02 15:07:10', '2024-07-02 15:07:10'),
(8, 117, 33, '2024-07-02 15:07:22', '2024-07-02 15:07:22'),
(9, 151, 33, '2024-07-02 15:07:26', '2024-07-02 15:07:26'),
(10, 157, 33, '2024-07-02 15:34:16', '2024-07-02 15:34:16'),
(11, 128, 31, '2024-07-03 12:13:20', '2024-07-03 12:13:20'),
(12, 122, 31, '2024-07-03 12:13:43', '2024-07-03 12:13:43'),
(13, 117, 31, '2024-07-03 12:14:28', '2024-07-03 12:14:28'),
(14, 151, 31, '2024-07-03 12:14:33', '2024-07-03 12:14:33');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Mathematics', 'For young learners, mathematics is an exciting journey of exploration and discovery. In introductory math courses, students engage in creative activities where they learn to count, compare, classify, solve problems, and have lots of fun along the way.', '2024-06-21 22:27:32', '2024-06-21 23:26:26'),
(2, 'English', 'In English grammar, the subject is a crucial element in sentences. It can be a noun, pronoun, or noun phrase that typically performs the action of the verb or is being described.', '2024-06-21 23:28:17', '2024-06-21 23:28:17');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `personal_team` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `user_id`, `name`, `personal_team`, `created_at`, `updated_at`) VALUES
(6, 8, 'Admin\'s Family', 1, '2024-06-23 06:40:44', '2024-06-23 06:40:44'),
(7, 9, 'Parent\'s Family', 1, '2024-06-23 06:45:08', '2024-06-23 06:45:08'),
(10, 13, 'Tutor\'s Family', 0, '2024-06-23 06:48:31', '2024-06-23 06:48:31'),
(11, 32, 'parentNEW\'s Family', 1, '2024-07-02 13:33:33', '2024-07-02 13:33:33'),
(13, 35, 'test@tutor.com\'s Family', 0, '2024-07-02 14:21:07', '2024-07-02 14:21:07');

-- --------------------------------------------------------

--
-- Table structure for table `team_invitations`
--

CREATE TABLE `team_invitations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_user`
--

CREATE TABLE `team_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_user`
--

INSERT INTO `team_user` (`id`, `team_id`, `user_id`, `role`, `created_at`, `updated_at`) VALUES
(4, 7, 31, 'student', '2024-06-29 16:26:40', '2024-06-29 16:26:40'),
(5, 11, 33, 'student', '2024-07-02 13:34:54', '2024-07-02 13:34:54');

-- --------------------------------------------------------

--
-- Table structure for table `text_contents`
--

CREATE TABLE `text_contents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `text_contents`
--

INSERT INTO `text_contents` (`id`, `course_id`, `content`, `created_at`, `updated_at`) VALUES
(5, 19, '<p>wooow a</p><h2>wooow a</h2><h3>wooow awooow awooow a</h3><h4>wooow a</h4><p><strong>wooow a</strong></p><p><i>wooow a</i></p><p><a href=\"test\">wooow a</a></p><p>&nbsp;</p><ul><li>awdaw</li><li>awd</li><li>awdawd</li></ul><p>&nbsp;</p><ol><li>awdad</li><li>awd</li><li>awd</li><li>aw</li></ol><p>&nbsp;</p><blockquote><p>awdawdaw</p></blockquote><figure class=\"table\"><table><tbody><tr><td>twooow a</td><td>wooow a</td><td>wooow a</td><td>wooow a</td><td>wooow a</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>&nbsp;</p><p>&nbsp;</p></td></tr></tbody></table></figure>', '2024-06-29 08:17:59', '2024-06-29 08:43:30'),
(6, 20, '<h2>Calculations adaw</h2><p>&nbsp;</p><blockquote><p>Welcome guys to my calculation guide,<br><br>&nbsp;test</p></blockquote><figure class=\"table\"><table><tbody><tr><td>1</td><td>x2</td><td>=</td><td>2</td></tr><tr><td>2</td><td>x2</td><td>=</td><td>4</td></tr><tr><td>3</td><td>x2</td><td>=</td><td>6</td></tr><tr><td>4</td><td>x2</td><td>=</td><td>8</td></tr><tr><td>5</td><td>x2</td><td>=</td><td>10</td></tr></tbody></table></figure>', '2024-06-29 14:29:30', '2024-07-04 16:05:57'),
(7, 27, '<p>You\'re reading this but it is not teaching you abaccus.<br><br>Stop reading now.</p>', '2024-07-04 15:58:15', '2024-07-04 15:58:15'),
(9, 29, '<p>test&nbsp;</p>', '2024-07-04 16:08:18', '2024-07-04 16:08:18'),
(10, 30, '<p>This is a little test</p>', '2024-07-07 10:01:59', '2024-07-07 10:01:59'),
(11, 31, '<p>wadawd</p>', '2024-07-07 11:41:47', '2024-07-07 11:41:47'),
(12, 32, '<p>adwawd</p>', '2024-07-07 11:43:03', '2024-07-07 11:43:03'),
(13, 33, '<p>awda</p>', '2024-07-07 11:43:16', '2024-07-07 11:43:16'),
(18, 39, '<p>dawdaw</p>', '2024-07-09 15:18:07', '2024-07-09 15:18:07');

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `program_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `course_id` int(11) NOT NULL,
  `author_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `name`, `program_id`, `subject_id`, `course_id`, `author_id`, `created_at`, `updated_at`) VALUES
(3, 'Addition and subtraction', 20, 1, 0, NULL, '2024-06-30 02:06:24', '2024-06-30 02:06:24'),
(4, 'Numbers', 20, 1, 0, NULL, '2024-06-30 02:06:38', '2024-06-30 02:06:56'),
(5, 'Time', 20, 2, 0, NULL, '2024-06-30 02:06:49', '2024-06-30 02:07:04'),
(6, 'Add and Subtract 2A', 24, 1, 0, NULL, '2024-06-30 02:18:49', '2024-06-30 02:18:49'),
(7, 'Add and Subtract 2B', 24, 1, 0, NULL, '2024-06-30 02:18:59', '2024-06-30 02:18:59'),
(8, 'Multiplication 1', 24, 1, 0, NULL, '2024-06-30 02:19:17', '2024-06-30 02:19:17'),
(9, 'Division 1', 25, 1, 0, NULL, '2024-06-30 02:19:41', '2024-06-30 02:19:41'),
(10, 'Early Geometry', 25, 2, 0, NULL, '2024-06-30 02:19:47', '2024-06-30 02:19:47'),
(11, 'Clock', 25, 2, 0, NULL, '2024-06-30 02:20:03', '2024-06-30 02:20:03'),
(12, 'Rounding', 26, 1, 0, NULL, '2024-07-02 14:11:03', '2024-07-02 14:11:03'),
(13, 'Verbs', 25, 2, 4, 13, '2024-07-02 15:15:39', '2024-07-09 15:16:54'),
(14, 'Abaccus', 20, 1, 3, 13, '2024-07-04 16:22:08', '2024-07-09 14:27:33'),
(16, 'Proverbs', 25, 2, 4, 13, '2024-07-04 17:05:28', '2024-07-09 13:39:46'),
(17, 'Pronoun', 25, 2, 4, 13, '2024-07-07 11:42:28', '2024-07-09 13:39:41'),
(21, 'Abaccus 2', 20, 1, 3, 13, '2024-07-09 15:17:43', '2024-07-09 15:17:43');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT 4,
  `grade` int(11) DEFAULT NULL,
  `subject` int(11) DEFAULT NULL,
  `status` tinyint(10) DEFAULT 1,
  `active` int(11) DEFAULT 0,
  `profile_photo_path` varchar(2048) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `current_team_id`, `role`, `grade`, `subject`, `status`, `active`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(8, 'Admin', 'admin@edunexus.test', NULL, '$2y$12$l/c4Ax0N6/mIhM04BDi.7uYmKtGLm57ayun3.paYi172Sif./rDuG', NULL, NULL, NULL, NULL, 6, 1, 20, NULL, 1, 1, NULL, '2024-06-23 06:40:44', '2024-07-05 16:15:29'),
(9, 'Parent', 'parent@edunexus.test', NULL, '$2y$12$Yu9ygE32DNx8r0FWnXxO3.WL7GWhEt/CMcx6FkULsVTBiWISo1BlK', NULL, NULL, NULL, NULL, 7, 2, NULL, NULL, 1, 1, NULL, '2024-06-23 06:45:08', '2024-07-02 14:17:46'),
(13, 'Tutor', 'tutor@edunexus.test', NULL, '$2y$12$lf5EgJQIxKEEnsU55bfrTOxKIsEKqjxqsiQFZ6ZboeTIBYAq/ig5.', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, 1, 1, NULL, '2024-06-23 06:48:31', '2024-06-23 06:48:50'),
(31, 'Hemwunt Khadun', 'hemant.khadun@gmail.com', NULL, '$2y$12$hHjBvWrpM8xjrrq6vu1AEulKwagrDF9ozyu.ri1QhqbpVnU8C66Qm', NULL, NULL, NULL, NULL, NULL, 4, 20, 1, 1, 1, NULL, '2024-06-29 16:26:36', '2024-07-08 16:08:15'),
(32, 'parentNEW', 'parentnew@test.com', NULL, '$2y$12$aWf.uH.cIuG8/q7ikzENO.hITThgwWdVyahosxc9V7U6mNX76aceW', 'eyJpdiI6ImNxbzlGQVFMTmFQYnE1Sm4zSHdWY0E9PSIsInZhbHVlIjoiY1B1WDdjNjhCYnlGcFVFUFJHaHUxQ3FlaTRNM0J3cUltS3gwcy9HZGRFTT0iLCJtYWMiOiIzMDRhOTYzMjhjNWNlYjk2YzlmYzc0MTFlODc5NDgxYTcxZDk0MjhkY2VjOWIzYWMzNTYzYmVkYzcxNzU1NmVmIiwidGFnIjoiIn0=', 'eyJpdiI6ImRyTms1TVhkaDhjNmVnYWNKeHdGUVE9PSIsInZhbHVlIjoiSFBzakhlb0R5VkhzQlJyLzZ0N3BlL3ozSW5McGEzTTZGV25hNGE0QTFYbUw2eFAva2l3aDc4WFBRUE5zTjJxSmQ2bnlPL2NhUHdXbkk4MTZIdEFLcUFWQStrZEZYaWZoWVZBODN1TW9XWGlkUC9zWENXeWkvK2dOY0NNNkc5ZmJKRHpobmZMeEY2NEc1VGwyMXQ2TGpnZXdINFdFb3JydmpSMCtncGRDSzlCQk1MSmRjbE5ZRUZJUFF0eFhTRll0Y2lWWXE2Y0JpQ1pJZThleXczVERQNk1tS2pLU0p4VG04dTBjSXJlTkRNTHI4RGszKzFxRGMxNlBwUXBWN0VhdHljVDhxVVYrano5blRDa2xvWkVaVGc9PSIsIm1hYyI6Ijc4N2Q0NTg2ZjdiZjQzYTQzOTg4MzQ2NGEzMWNmZmExYTgyNDNhY2U4OGQ1YmFiOTg1OWU5N2JhNDc5OWFhNGUiLCJ0YWciOiIifQ==', '2024-07-02 13:41:35', NULL, 11, 2, NULL, NULL, 1, 1, 'profile-photos/5Kd6n124ZteWlTnNeFknXkLn0Rv26ywtxTlUIaVk.png', '2024-07-02 13:33:33', '2024-07-02 13:41:35'),
(33, 'Test Student', 'swaema04@gmail.com', NULL, '$2y$12$tzjy9tYffHpichs9tSoSkOvCAPcTluyt0E27rfHqWlMxJj192HmJa', NULL, NULL, NULL, NULL, NULL, 4, 20, NULL, 1, 1, NULL, '2024-07-02 13:34:50', '2024-07-05 17:53:36'),
(35, 'test@tutor.com', 'test@tutor.com', NULL, '$2y$12$D8V7yUZFahyICEivFZ70..ne0/OTfFAOkS5AOa4jZvayc0eyzXNka', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, 1, 1, NULL, '2024-07-02 14:21:07', '2024-07-02 14:25:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `completed_courses`
--
ALTER TABLE `completed_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `courses_subject_id_foreign` (`subject_id`),
  ADD KEY `courses_material_id_foreign` (`material_id`),
  ADD KEY `courses_program_id_foreign` (`program_id`),
  ADD KEY `courses_author_id_foreign` (`author_id`),
  ADD KEY `courses_topic_id_foreign` (`topic_id`),
  ADD KEY `courses_wrapper_id_index` (`wrapper_id`),
  ADD KEY `courses_category_id_index` (`category_id`) USING BTREE;

--
-- Indexes for table `course_wrappers`
--
ALTER TABLE `course_wrappers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_wrappers_author_id_foreign` (`author_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `materials`
--
ALTER TABLE `materials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `media_uuid_unique` (`uuid`),
  ADD KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  ADD KEY `media_order_column_index` (`order_column`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_course_id` (`course_id`);

--
-- Indexes for table `quiz_answers`
--
ALTER TABLE `quiz_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_quiz_id` (`quiz_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `student_answers`
--
ALTER TABLE `student_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_answers_user_id_foreign` (`user_id`),
  ADD KEY `fk_student_answers_answer_id` (`answer_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teams_user_id_index` (`user_id`);

--
-- Indexes for table `team_invitations`
--
ALTER TABLE `team_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `team_invitations_team_id_email_unique` (`team_id`,`email`);

--
-- Indexes for table `team_user`
--
ALTER TABLE `team_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `team_user_team_id_user_id_unique` (`team_id`,`user_id`);

--
-- Indexes for table `text_contents`
--
ALTER TABLE `text_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `text_contents_course_id` (`course_id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `topics_program_id_foreign` (`program_id`),
  ADD KEY `topics_author_id_foreign` (`author_id`),
  ADD KEY `topics_subject_id_foreign` (`subject_id`) USING BTREE,
  ADD KEY `topics_course_id_foreign` (`course_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `completed_courses`
--
ALTER TABLE `completed_courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `course_wrappers`
--
ALTER TABLE `course_wrappers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `followers`
--
ALTER TABLE `followers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `materials`
--
ALTER TABLE `materials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `quiz_answers`
--
ALTER TABLE `quiz_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT for table `student_answers`
--
ALTER TABLE `student_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `team_invitations`
--
ALTER TABLE `team_invitations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `team_user`
--
ALTER TABLE `team_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `text_contents`
--
ALTER TABLE `text_contents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `courses_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`),
  ADD CONSTRAINT `courses_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`),
  ADD CONSTRAINT `courses_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  ADD CONSTRAINT `courses_topic_id_foreign` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`);

--
-- Constraints for table `course_wrappers`
--
ALTER TABLE `course_wrappers`
  ADD CONSTRAINT `course_wrappers_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD CONSTRAINT `course_id` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_course_id` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_answers`
--
ALTER TABLE `quiz_answers`
  ADD CONSTRAINT `fk_quiz_id` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quiz_answers_quiz_id_foreign` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`);

--
-- Constraints for table `student_answers`
--
ALTER TABLE `student_answers`
  ADD CONSTRAINT `fk_student_answers_answer_id` FOREIGN KEY (`answer_id`) REFERENCES `quiz_answers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_answers_answer_id_foreign` FOREIGN KEY (`answer_id`) REFERENCES `quiz_answers` (`id`),
  ADD CONSTRAINT `student_answers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `team_invitations`
--
ALTER TABLE `team_invitations`
  ADD CONSTRAINT `team_invitations_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `text_contents`
--
ALTER TABLE `text_contents`
  ADD CONSTRAINT `text_contents_course_id` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `text_contents_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `topics`
--
ALTER TABLE `topics`
  ADD CONSTRAINT `topics_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `topics_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`);
--
-- Database: `final`
--
CREATE DATABASE IF NOT EXISTS `final` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `final`;

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `fol_id` int(11) NOT NULL,
  `fol_status` varchar(20) DEFAULT NULL,
  `tut_id` int(11) DEFAULT NULL,
  `std_id` int(11) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `subj_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `grade_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`grade_id`, `title`, `description`, `image_path`, `created_at`) VALUES
(25, 'Grade 1', 'grade 1 description', 'uploads/g1.png', '2024-06-12 17:20:59'),
(26, 'Grade 2', 'grade 2 description', 'uploads/g22.png', '2024-06-13 11:06:56'),
(28, 'Grade 3', 'grade 3 desc', 'uploads/g33.png', '2024-06-13 12:00:25'),
(30, 'Grade 4', 'Grade 4 description', 'uploads/g4.png', '2024-06-13 12:37:08');

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE `material` (
  `mat_id` int(11) NOT NULL,
  `mat_title` varchar(255) NOT NULL,
  `mat_description` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `top_id` int(11) DEFAULT NULL,
  `mt_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `material`
--

INSERT INTO `material` (`mat_id`, `mat_title`, `mat_description`, `file_path`, `creation_date`, `top_id`, `mt_id`) VALUES
(1, 'first materials', 'first material description', 'uploads/Tan No.pdf', '2024-06-14 09:19:08', 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mat_type`
--

CREATE TABLE `mat_type` (
  `mt_id` int(11) NOT NULL,
  `mt_name` varchar(30) NOT NULL,
  `description` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mat_type`
--

INSERT INTO `mat_type` (`mt_id`, `mt_name`, `description`) VALUES
(1, 'Lecture', 'it contains pdf, video, word'),
(3, 'Game', 'Developed by Contruct 3'),
(5, 'Quiz', 'quiz description');

-- --------------------------------------------------------

--
-- Table structure for table `parent`
--

CREATE TABLE `parent` (
  `prt_id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parent`
--

INSERT INTO `parent` (`prt_id`, `firstName`, `lastName`, `email`, `password`) VALUES
(1, 'Fatema', 'Hosenbocus', 'fatema@gmail.com', '$2y$10$vh6DRBUOc5qjZwHnubQpluCIHsxcJXdNn.8I9po2jL3jdyGkNqg4G'),
(4, 'jalil', 'moullan', 'jalil@gmail.com', '$2y$10$qO7eDyW2lALZ81zmiDqEGOkJqN8VwJwgfdSaJgdGKtOBhiGeJEjfO'),
(5, 'naksu', 'naksu', 'naksu@gmail.com', '$2y$10$VPjS0.Z87XrPQpO71TBGRevNmBTNySybxFOjloVSjUJOVmVlZkVR6'),
(6, 'james', 'bond', 'james@gmail.com', '$2y$10$zn.qslRkr0c/RWSFDnnEmOr0mTru3k966SpXhVVvyQeNTo3BdXb16'),
(7, 'Clark', 'Bacon', 'clark@gmail.com', '$2y$10$Wl3UBy0S9zcPQRYj8L.rnufqRvro7FPVsPnObtmC/AruvRG.mExAa'),
(8, 'james', 'potter', 'jpotter@gmail.com', '$2y$10$UBbKCDiB7joFr..riDRd8O4bzzRQM1FxAMLa8qP18eR7yRmnfvuRm'),
(12, 'sakura', 'uchiha', 'sakura@gmail.com', '$2y$10$8PkVgsgLCvULNYxrM.7an.jTmoAzKXvRwd2vvxA4y/RINw8h3i16K'),
(17, 'Swae', 'Hosenbocussss', 'swae@gmail.com', '$2y$10$kNRzZl1QJE2OX5Y0jS5nFOuk27iJiYvH.xgG.6rwhb.pbEC1Q.LEu'),
(18, 'test parent', 'test last partent', 'test@test.com', '$2y$10$0TLrMi3fkJxq2QpnWksstedGG4qjU.Joezf.5o3sYEov10Zn8n7m6');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `std_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`std_id`, `parent_id`, `firstName`, `lastName`, `username`, `dob`) VALUES
(1, 1, 'Array', 'Array', 'swae', '1970-01-01'),
(4, 4, 'lucy', 'moullan', 'lucy', '1970-01-01'),
(6, 5, 'jang', 'uk', 'jangg', '1970-01-01'),
(7, 6, 'aina', 'bond', 'aina', '1970-01-01'),
(8, 7, 'Chris', 'Bacon', 'chris', '1970-01-01'),
(9, 8, 'harry', 'potter', 'harry', '1970-01-01'),
(13, 12, 'sarada', 'uchiha', 'sarada', '1970-01-01'),
(19, 17, 'Coquillee', 'Hosenbocus', 'coquille', '2017-09-02'),
(20, 17, 'Mitounda', 'Hosenbocus', 'mitou', '2016-02-03'),
(21, 18, 'test', 'test last', 'test', '1000-10-10');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subj_id` int(11) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `subject_title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `tut_id` int(11) DEFAULT NULL,
  `st_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subj_id`, `subject_code`, `subject_title`, `description`, `grade_id`, `tut_id`, `st_id`) VALUES
(35, 'mwyU59zh', 'English Volume 1', 'Learning the basic', 25, 1, 1),
(36, 'UzN9Z6tF', 'English Volume 2', 'Starting with vocabulary', 25, 1, 1),
(37, 'TZY7wpBi', 'Maths with Sensei ', 'desc', 26, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `subj_type`
--

CREATE TABLE `subj_type` (
  `st_id` int(11) NOT NULL,
  `st_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subj_type`
--

INSERT INTO `subj_type` (`st_id`, `st_name`, `description`) VALUES
(1, 'English', 'English Descriptions'),
(3, 'Mathematics', 'Mathematics description');

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `top_id` int(11) NOT NULL,
  `subj_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`top_id`, `subj_id`, `title`, `description`) VALUES
(15, 35, 'Vocabulary Building', 'A for Apples'),
(17, 35, 'Second topic', 'second topic description'),
(20, 35, 'third topic', 'third topic description');

-- --------------------------------------------------------

--
-- Table structure for table `tutor`
--

CREATE TABLE `tutor` (
  `tut_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `experience` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `secret_question` varchar(30) NOT NULL,
  `secret_answer` varchar(20) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `gender` enum('male','female','other') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tutor`
--

INSERT INTO `tutor` (`tut_id`, `first_name`, `last_name`, `email`, `experience`, `password`, `secret_question`, `secret_answer`, `status`, `gender`) VALUES
(1, 'Naruto', 'uzumaki', 'naruto@gmail.com', 3, '$2y$10$c/dSupo0SOraC9zc66H91eg2h2ZAxt/J80BojkG.6rq5dUduOfDXC', '', '', 'approved', 'male'),
(2, 'sasuke', 'uchiha', 'sasuke@gmail.com', 1, '$2y$10$4eeGuunZbSpN4xTtSlkfJOf1Mky7.FDZBGKd2f017/9dvAPvlcw7S', '', '', 'rejected', 'male'),
(7, 'John', 'Wick', 'john@gmail.com', 3, '$2y$10$lo1sAkGruS5qnHX9Gs7PTeLVEQKpiNy5U0I3ACjaHF/ZM6vlcBOrW', '', '', 'approved', 'male'),
(34, 'rock', 'lee', 'rock@gmail.com', 2, '$2y$10$PKxAR4Pmy1dqTxw4A1pHoObo1oen7MhDO3/2jMJ2bXynGDvUFyape', 'what is your wish', 'to become strong', 'rejected', 'male'),
(35, 'minato', 'namikaze', 'minato@gmail.com', 3, '$2y$10$9rZYVvBB7ngpRNZq8VyKi.GydIsJZWvKjUMj4j9BJerKX4sEF32aS', 'what is your favourite food', 'pizza', 'approved', 'male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`fol_id`),
  ADD KEY `tut_id` (`tut_id`),
  ADD KEY `std_id` (`std_id`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `subj_id` (`subj_id`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`grade_id`);

--
-- Indexes for table `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`mat_id`),
  ADD KEY `top_id` (`top_id`),
  ADD KEY `mt_id` (`mt_id`);

--
-- Indexes for table `mat_type`
--
ALTER TABLE `mat_type`
  ADD PRIMARY KEY (`mt_id`);

--
-- Indexes for table `parent`
--
ALTER TABLE `parent`
  ADD PRIMARY KEY (`prt_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`std_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subj_id`),
  ADD UNIQUE KEY `subject_code` (`subject_code`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `fk_subject_tutor` (`tut_id`),
  ADD KEY `fk_subject_st_id` (`st_id`);

--
-- Indexes for table `subj_type`
--
ALTER TABLE `subj_type`
  ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`top_id`),
  ADD KEY `subj_id` (`subj_id`);

--
-- Indexes for table `tutor`
--
ALTER TABLE `tutor`
  ADD PRIMARY KEY (`tut_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `followers`
--
ALTER TABLE `followers`
  MODIFY `fol_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `grade`
--
ALTER TABLE `grade`
  MODIFY `grade_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `material`
--
ALTER TABLE `material`
  MODIFY `mat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mat_type`
--
ALTER TABLE `mat_type`
  MODIFY `mt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `parent`
--
ALTER TABLE `parent`
  MODIFY `prt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `std_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subj_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `subj_type`
--
ALTER TABLE `subj_type`
  MODIFY `st_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `top_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tutor`
--
ALTER TABLE `tutor`
  MODIFY `tut_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followers_ibfk_1` FOREIGN KEY (`tut_id`) REFERENCES `tutor` (`tut_id`),
  ADD CONSTRAINT `followers_ibfk_2` FOREIGN KEY (`std_id`) REFERENCES `student` (`std_id`),
  ADD CONSTRAINT `followers_ibfk_3` FOREIGN KEY (`grade_id`) REFERENCES `grade` (`grade_id`),
  ADD CONSTRAINT `followers_ibfk_4` FOREIGN KEY (`subj_id`) REFERENCES `subject` (`subj_id`);

--
-- Constraints for table `material`
--
ALTER TABLE `material`
  ADD CONSTRAINT `material_ibfk_1` FOREIGN KEY (`top_id`) REFERENCES `topics` (`top_id`),
  ADD CONSTRAINT `material_ibfk_2` FOREIGN KEY (`mt_id`) REFERENCES `mat_type` (`mt_id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `parent` (`prt_id`) ON DELETE CASCADE;

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `fk_subject_st_id` FOREIGN KEY (`st_id`) REFERENCES `subj_type` (`st_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_subject_tutor` FOREIGN KEY (`tut_id`) REFERENCES `tutor` (`tut_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`grade_id`) REFERENCES `grade` (`grade_id`);

--
-- Constraints for table `topics`
--
ALTER TABLE `topics`
  ADD CONSTRAINT `fk_subj_id` FOREIGN KEY (`subj_id`) REFERENCES `subject` (`subj_id`),
  ADD CONSTRAINT `topics_ibfk_1` FOREIGN KEY (`subj_id`) REFERENCES `subject` (`subj_id`) ON DELETE CASCADE;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"edu_nexus\",\"table\":\"materials\"},{\"db\":\"edu_nexus\",\"table\":\"subjects\"},{\"db\":\"edu_nexus\",\"table\":\"completed_courses\"},{\"db\":\"edu_nexus\",\"table\":\"courses\"},{\"db\":\"edu_nexus\",\"table\":\"student_answers\"},{\"db\":\"edu_nexus\",\"table\":\"topics\"},{\"db\":\"edu_nexus\",\"table\":\"programs\"},{\"db\":\"edu_nexus\",\"table\":\"quiz_answers\"},{\"db\":\"edu_nexus\",\"table\":\"quizzes\"},{\"db\":\"edu_nexus\",\"table\":\"text_contents\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'edu_nexus', 'courses', '{\"sorted_col\":\"`courses`.`topic_id` DESC\"}', '2024-07-02 20:30:27'),
('root', 'edu_nexus', 'quiz_answers', '{\"sorted_col\":\"`quiz_answers`.`id` DESC\"}', '2024-07-02 16:32:26');

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2024-07-03 16:00:20', '{\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
